# Databricks notebook source
# MAGIC %sql
# MAGIC select * FROM genai_prd_psql_catalog.public.tsmfapb01 LIMIT 10

# COMMAND ----------

storage_account_name = "your_storage_account_name"
sas_token = "your_sas_token"
container_name = "your_container_name"

spark.conf.set(
)
