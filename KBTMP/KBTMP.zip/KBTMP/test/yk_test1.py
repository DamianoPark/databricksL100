# Databricks notebook source
df = spark.read.format("csv", header=False, inferSchema=True).load("https://cmheadevgenaikb0.blob.core.windows.net/cm-hea-dev-genai-blob-tmp/KB0/rdb/20250421132904/kb0_mfa_tsmfapb01_20250401132830.dat")

# COMMAND ----------

spark.conf.set("fs.azure.account.auth.type.cmheadevgenaikb0.dfs.core.windows.net", "SAS")
spark.conf.set("fs.azure.sas.token.provider.type.cmheadevgenaikb0.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.sas.FixedSASTokenProvider")
# spark.conf.set("fs.azure.sas.fixed.token.cmheadevgenaikb0.dfs.core.windows.net", dbutils.secrets.get(scope="<scope>", key="<sas-token-key>"))
spark.conf.set("fs.azure.sas.fixed.token.cmheadevgenaikb0.dfs.core.windows.net", "sp=racwdli&st=2025-04-22T08:47:35Z&se=2025-05-09T16:47:35Z&spr=https&sv=2024-11-04&sr=c&sig=sBgfzHMPKWZuxqILlh470NMjSVnFXDO7PZ87LWHIln0%3D")


# COMMAND ----------

# MAGIC %fs ls https://cmheadevgenaikb0.blob.core.windows.net/cm-hea-dev-genai-blob-tmp

# COMMAND ----------

# MAGIC %fs ls /

# COMMAND ----------

