# Databricks notebook source
# MAGIC %md
# MAGIC # AI Lakehouse
# MAGIC ## Ingest 대상 테이블 리스트 생성
# MAGIC - job_start_time: job parameter 에서 설정한 {{job.start_time.iso_datetime}} 값
# MAGIC - landing_zone: Unity Catalog Volume '/Volumes/pbagent/genai/oracle_prd_raw/rdb/'

# COMMAND ----------

# DBTITLE 1,Job Start Time 값을 %Y%m%d%H%M%S 형태로 변환
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo


job_start_time = datetime.fromisoformat(dbutils.widgets.get("job_start_time").replace("Z", "+00:00")).astimezone(ZoneInfo("Asia/Seoul")) 
end_time = job_start_time.strftime("%Y%m%d%H%M%S")
start_time = (job_start_time - timedelta(hours=36)).strftime("%Y%m%d%H%M%S")

print("job_start_time: ", job_start_time)
print("start_time: ", start_time)
print("end_time: ", end_time)

# COMMAND ----------

# DBTITLE 1,Landing_zone 하위 경로 중 start_time <= 경로 < end_time 에 해당하는 경로만 리스팅
landing_zone = dbutils.fs.ls("/Volumes/pbagent/genai/oracle_prd_raw/rdb/")
dir_list = []
for dir in landing_zone:
    if dir.name.startswith("20"):
        name =  dir.name.rstrip('/')
        dt = datetime.strptime(name, "%Y%m%d%H%M%S")
        if datetime.strptime(start_time, "%Y%m%d%H%M%S") <= dt < datetime.strptime(end_time, "%Y%m%d%H%M%S"):
                dir_list.append(dir.name)

print(dir_list)

# COMMAND ----------

# DBTITLE 1,3번에 해당하는 경로에 있는 파일명에서 테이블명 추출
table_list = []

for dir in dir_list:
    tables = dbutils.fs.ls(f"/Volumes/pbagent/genai/oracle_prd_raw/rdb/{dir}")
    for t in tables:
        if t.name.startswith("kb0"):
            table = t.name.split("_")[2]
            table_list.append(table)

table_list = list(set(table_list))
print(table_list)

# COMMAND ----------

# DBTITLE 1,table_list를 task value로 설정
dbutils.jobs.taskValues.set(key = "table_list", value = table_list)