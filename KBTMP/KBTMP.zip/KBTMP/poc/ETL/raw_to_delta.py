# Databricks notebook source
# MAGIC %md
# MAGIC # AI Lakehouse
# MAGIC ## 데이터 수집
# MAGIC - csv 파일 적재 경로: (스토리지계정) kb0heaprdgenai / (컨테이너) cm-hea-prd-genai-blob-tmp
# MAGIC - table 경로: pbagent.genai.{table}

# COMMAND ----------

# DBTITLE 1,table_name 파라미터 및 landing존 설정
table_name = dbutils.widgets.get("table_name")
landing_zone = "/Volumes/pbagent/genai/oracle_prd_raw/rdb/"

print("table_name: ", table_name)
print("landing_zone: ", landing_zone)

# COMMAND ----------

# DBTITLE 1,본 task에서 사용할 CATALOG 및 SCHEMA 설정
spark.sql("USE CATALOG pbagent")
spark.sql("USE SCHEMA genai")

# COMMAND ----------

# DBTITLE 1,Auto Loader를 사용한 read 및 merge(upsert)

from pyspark.sql.functions import *
from delta.tables import DeltaTable


def upsert_to_delta(batch_df, batch_id):
    if not batch_df.isEmpty():

        # 타겟 테이블의 PK 컬럼 가져오기
        pk_q = f"""
            select column_name 
            from pbagent.information_schema.key_column_usage
            where table_schema = 'genai'
                and table_name = '{table_name}'
                and constraint_name in (
                    select constraint_name 
                    from pbagent.information_schema.table_constraints 
                    where table_name = '{table_name}' 
                    and constraint_type = 'PRIMARY KEY'
                )
            order by ordinal_position
            """
        pks = [row['column_name'] for row in spark.sql(pk_q).collect()]

        # merge condition 생성
        merge_condition = " AND ".join(f"target.`{col}` = source.`{col}`" for col in pks)

        # merge_condition 유무
        if not merge_condition:
            # append 실행
            batch_df.write.mode("append").saveAsTable(table_name)
        else:
            # merge 실행
            if spark.catalog.tableExists(table_name):
                DeltaTable.forName(spark, table_name).alias("target").merge(
                    batch_df.dropna(subset=pks).dropDuplicates(pks).alias("source"),
                    condition=merge_condition
                ).whenMatchedUpdateAll()\
                .whenNotMatchedInsertAll()\
                .execute()

# 테이블이 있는지 확인
if spark.catalog.tableExists(table_name):
    print(f"{table_name} is loading.. ")

    try: 
        # 타겟 테이블 schema 가져오기
        schema = spark.table(table_name).schema

        bronze_df = (spark.readStream
                .format("cloudFiles")
                .option("cloudfiles.format", "csv")
                .option("delimiter", "|")
                .option("header", "false")
                .option("cloudFiles.maxFilesPerTrigger", "100") # default 1000
                .option("pathGlobfilter", "*_"+table_name+"_*")
                .schema(schema)
                .load(f"{landing_zone}")
        )

        query = (bronze_df.writeStream
                .foreachBatch(upsert_to_delta)
                .option("checkpointLocation", f"{landing_zone}/checkpoints/{table_name}")
                .trigger(availableNow=True)
                .start()
        )

        print(f"{table_name} merge completed.")            
    
    except Exception as e:
        print(f"{table_name} Error: {e}")
    
else:
    print(f"{table_name} does not exist.")