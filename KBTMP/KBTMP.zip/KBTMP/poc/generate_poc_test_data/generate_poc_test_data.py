# Databricks notebook source
# MAGIC %md
# MAGIC # Original script
# MAGIC ```
# MAGIC DECLARE counting DATE DEFAULT DATE '2023-02-01'; 
# MAGIC DECLARE etlbaseymd STRING; 
# MAGIC DECLARE y INT64; 
# MAGIC DECLARE x INT64; 
# MAGIC  
# MAGIC LOOP 
# MAGIC   SET y = 1; 
# MAGIC   WHILE y <= 12 DO 
# MAGIC     SET x = 1; 
# MAGIC     WHILE x <= 30 DO 
# MAGIC       SET etlbaseymd = FORMAT_DATE('%Y%m%d', counting); 
# MAGIC       EXECUTE IMMEDIATE FORMAT('INSERT INTO kb-bq-poc-240403.poc.test_poc (movieid, rating, dates, etlbaseymd) 
# MAGIC SELECT movie_id, rating, date, "%s" FROM kb-bq-poc-240403.poc.poc_data', etlbaseymd); 
# MAGIC       SET counting = DATE_ADD(counting, INTERVAL 1 DAY); 
# MAGIC       SET x = x + 1; 
# MAGIC     END WHILE; 
# MAGIC     SET y = y + 1; 
# MAGIC   END WHILE; 
# MAGIC END LOOP; 
# MAGIC ```

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE lakehouse.poc.test_poc (
# MAGIC   movieid INT,
# MAGIC   rating FLOAT,
# MAGIC   dates DATE,
# MAGIC   etlbaseymd STRING
# MAGIC )
# MAGIC CLUSTER BY (dates, movieid, etlbaseymd);

# COMMAND ----------

# MAGIC %sql
# MAGIC LIST "/Volumes/lakehouse/netflixdata/netflixdata/netflixdata.zip"

# COMMAND ----------

# MAGIC %sh
# MAGIC

# COMMAND ----------

# MAGIC %sh 
# MAGIC zcat -d /Volumes/lakehouse/netflixdata/netflixdata/netflixdata.zip > /Volumes/lakehouse/netflixdata/netflixdata/netflixdata.csv

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM csv.`/Volumes/lakehouse/netflixdata/netflixdata/netflixdata.csv` limit 10;

# COMMAND ----------

# MAGIC %sql select count(*) from csv.`/Volumes/lakehouse/netflixdata/netflixdata/netflixdata.csv`

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE lakehouse.poc.neflixdata 
# MAGIC AS 
# MAGIC SELECT * FROM read_files(
# MAGIC   '/Volumes/lakehouse/netflixdata/netflixdata/netflixdata.csv',
# MAGIC   format => 'csv',
# MAGIC   header => true,
# MAGIC   mode => 'FAILFAST')

# COMMAND ----------

# MAGIC %sql select count(*) from lakehouse.poc.neflixdata;

# COMMAND ----------

import re
from datetime import timedelta, datetime 

start_dt = "20230201"
dt = datetime.strptime(start_dt, "%Y%m%d")

for i in range(0, 200):  # 200 days, approx 20 bil rows
    newdt = dt + timedelta(days=i)
    newdt_ymd = newdt.strftime("%Y%m%d")
    # print(newdt_ymd)
    sql = f"""
        INSERT INTO lakehouse.poc.test_poc (movieid, rating, dates, etlbaseymd) 
        SELECT movie_id, rating, `date`, '{newdt_ymd}' FROM lakehouse.poc.neflixdata
    """
    print(sql)
    spark.sql(sql)


# COMMAND ----------

# MAGIC %sql 
# MAGIC OPTIMIZE lakehouse.poc.test_poc FULL;

# COMMAND ----------

# MAGIC %sql
# MAGIC ANALYZE TABLE lakehouse.poc.test_poc COMPUTE STATISTICS  FOR ALL COLUMNS;