# Databricks notebook source
# MAGIC %md
# MAGIC # NYC TAXI Data Get 
# MAGIC
# MAGIC 참고 쿼리  
# MAGIC ```
# MAGIC CREATE TABLE lakehouse.poc.nyc ( 
# MAGIC hvfhs_license_num STRING, 
# MAGIC request_datetime DATETIME GENERATED ALWAYS AS (TO_CHAR(request_datetime AS STRING)), 
# MAGIC ... 
# MAGIC ) 
# MAGIC CLUSTER BY (hvfhs_license_num, request_datetime)
# MAGIC ```

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE lakehouse.poc.nyctaxi (
# MAGIC   Hvfhs_license_num STRING,
# MAGIC   Dispatching_base_num STRING,
# MAGIC   Pickup_datetime TIMESTAMP,
# MAGIC   DropOff_datetime INT,
# MAGIC   PULocationID INT,
# MAGIC   DOLocationID INT,
# MAGIC   originating_base_num 
# MAGIC )
# MAGIC CLUSTER BY (hvfhs_license_num, request_datetime);

# COMMAND ----------

# MAGIC %sql
# MAGIC LIST "/Volumes/lakehouse/testdata/nyctaxi"

# COMMAND ----------

# 1. Python으로 해제
import zipfile, os

zip_path = "/Volumes/lakehouse/testdata/nyctaxi/nyctaxi.zip"
extract_dir = "/Volumes/lakehouse/testdata/nyctaxi"

os.makedirs(extract_dir, exist_ok=True)
with zipfile.ZipFile(zip_path) as z:
    z.extractall(extract_dir)       # 모든 parquet 파일 전개


# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE lakehouse.poc.nyc_replace AS  
# MAGIC SELECT * FROM read_files("/Volumes/lakehouse/testdata/nyctaxi/*.parquet", format => 'parquet');

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE lakehouse.poc.nyc_replace_1 AS  
# MAGIC SELECT * FROM lakehouse.poc.nyc_replace limit 0;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- 클러스터링 키 지정
# MAGIC ALTER TABLE lakehouse.poc.nyctaxi
# MAGIC CLUSTER BY (hvfhs_license_num, request_datetime);
# MAGIC
# MAGIC -- 물리 레이아웃을 실제로 재정렬
# MAGIC OPTIMIZE lakehouse.poc.nyctaxi;

# COMMAND ----------

# MAGIC %sql
# MAGIC ANALYZE TABLE lakehouse.poc.nyctaxi COMPUTE STATISTICS  FOR ALL COLUMNS;

# COMMAND ----------

# MAGIC %md
# MAGIC 500mb csv 생성

# COMMAND ----------

# Load part of the nyctaxi table into a DataFrame
nyctaxi_df = spark.table("lakehouse.poc.nyctaxi").limit(50000*60)

# Write the sampled data to a CSV file
output_path = "/Volumes/lakehouse/testdata/nyctaxi/nyctaxi_500mb/sample_nyctaxi.csv"
nyctaxi_df.coalesce(1).write.mode('overwrite').csv(output_path, header=True)

# COMMAND ----------

# MAGIC %md
# MAGIC replace query 용 데이터 생성

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE lakehouse.poc.nyc_replace CLONE lakehouse.poc.nyctaxi;

# COMMAND ----------

# MAGIC %md
# MAGIC APPEND용 데이터 생성

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE lakehouse.poc.nyc_append AS SELECT * FROM lakehouse.poc.nyctaxi LIMIT 1000000;

# COMMAND ----------

