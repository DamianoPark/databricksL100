-- Databricks notebook source
-- MAGIC %md
-- MAGIC ## 14.1. 테이블 컬럼 타입 변경 및 추가 

-- COMMAND ----------

DROP TABLE IF EXISTS pocdemo.uc_demo_db.ext34

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS pocdemo.uc_demo_db.ext34 (
    num int,
    name string
)

-- COMMAND ----------

INSERT INTO  pocdemo.uc_demo_db.ext34 VALUES (1, 'aa'), (2, 'bb'), (3, 'cc')

-- COMMAND ----------

ALTER TABLE pocdemo.uc_demo_db.ext34 SET TBLPROPERTIES (
   'delta.minReaderVersion' = '2',
   'delta.minWriterVersion' = '5',
   'delta.columnMapping.mode' = 'name'
)

-- COMMAND ----------

ALTER TABLE pocdemo.uc_demo_db.ext34 RENAME COLUMN name TO newname;

-- COMMAND ----------

SELECT * FROM pocdemo.uc_demo_db.ext34 

-- COMMAND ----------

-- DBTITLE 1,Add Column
ALTER TABLE pocdemo.uc_demo_db.ext34 ADD COLUMN (mysecondcol string COMMENT 'added to 2nd column' AFTER num);

-- COMMAND ----------

DESC pocdemo.uc_demo_db.ext34

-- COMMAND ----------

SELECT * FROM pocdemo.uc_demo_db.ext34;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC from pyspark.sql.functions import col
-- MAGIC
-- MAGIC (spark.read.table("pocdemo.uc_demo_db.ext34")
-- MAGIC   .withColumn("mysecondcol", col("mysecondcol").cast("date"))
-- MAGIC   .write
-- MAGIC   .mode("overwrite")
-- MAGIC   .option("overwriteSchema", "true")
-- MAGIC   .saveAsTable("pocdemo.uc_demo_db.ext34")
-- MAGIC )

-- COMMAND ----------

DESC pocdemo.uc_demo_db.ext34;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 14.3. Table PK 지정 및 not null 지정 

-- COMMAND ----------

CREATE TABLE pocdemo.uc_demo_db.test_constraint (
  num INT NOT NULL, name STRING NOT NULL, amount INT, 
  CONSTRAINT test_constraint_pk PRIMARY KEY (num)
);

-- COMMAND ----------

INSERT INTO pocdemo.uc_demo_db.test_constraint VALUES 
(1, 'kim', 100),
(2, 'hof', 110),
(3, 'han', null );

-- COMMAND ----------

-- DBTITLE 1,NOT NULL constraint is mandatory
INSERT INTO pocdemo.uc_demo_db.test_constraint VALUES 
(4, null, 100);

-- COMMAND ----------

-- DBTITLE 1,PK is informational, not enforced
INSERT INTO pocdemo.uc_demo_db.test_constraint VALUES 
(1, 'zon', 500);

-- COMMAND ----------

SELECT * FROM pocdemo.uc_demo_db.test_constraint

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 14.4. 컬럼 변경 API 지원 여부

-- COMMAND ----------

-- MAGIC %sh 
-- MAGIC export DATABRICKS_TOKEN="dapi566f4c5793f8b2be6e2cc6332012a26b"
-- MAGIC
-- MAGIC curl -X POST -k --header "Authorization: Bearer $DATABRICKS_TOKEN" \
-- MAGIC   https://dbpoc-kbpoc-ext.cloud.databricks.com/api/2.0/sql/statements/ \
-- MAGIC   -d '{
-- MAGIC   "warehouse_id": "2a28a21a4d8e39bc",
-- MAGIC   "statement": "ALTER TABLE pocdemo.uc_demo_db.ext34 RENAME COLUMN newname TO newname_by_api;",
-- MAGIC   "wait_timeout": "0s"
-- MAGIC }'

-- COMMAND ----------

DESC pocdemo.uc_demo_db.ext34

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 14.5. 지원 데이터 타입 
-- MAGIC * Spark SQL 데이터 타입 문서: https://spark.apache.org/docs/latest/sql-ref-datatypes.html

-- COMMAND ----------

CREATE TABLE pocdemo.uc_demo_db.test_datatype (
  num INT, name VARCHAR(16), tagcode CHAR(4), amount DECIMAL(5, 3)
);

-- COMMAND ----------

DESC FORMATTED pocdemo.uc_demo_db.test_datatype

-- COMMAND ----------

INSERT INTO pocdemo.uc_demo_db.test_datatype VALUES 
(1, 'aaa', 'aa', 12.345);

-- COMMAND ----------

SELECT num, name, length(name), tagcode, length(tagcode), amount FROM pocdemo.uc_demo_db.test_datatype

-- COMMAND ----------

-- DBTITLE 1,char(4) 타입 컬럼에 5글자 입력 테스트 
INSERT INTO pocdemo.uc_demo_db.test_datatype VALUES 
(2, 'aaa', 'aaaaa', 2.3456);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 14.7. 테이블 포맷 지원시 external table 의 CRUD 여부

-- COMMAND ----------

-- MAGIC %

-- COMMAND ----------

DROP TABLE IF EXISTS pocdemo.uc_demo_db.ext147_delta PURGE; 

CREATE TABLE pocdemo.uc_demo_db.ext147_delta (num int, name string)
LOCATION 's3://kbpoc-ext-tmp/data/ext147_delta'

-- COMMAND ----------

INSERT INTO  pocdemo.uc_demo_db.ext147_delta VALUES (1, 'aa'), (2, 'bb');

-- COMMAND ----------

UPDATE pocdemo.uc_demo_db.ext147_delta SET num = 3 WHERE num = 2;

-- COMMAND ----------

DELETE FROM pocdemo.uc_demo_db.ext147_delta  WHERE num = 1;

-- COMMAND ----------

SELECT * FROM pocdemo.uc_demo_db.ext147_delta

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS pocdemo.uc_demo_db.ext147_csv (num int, name string)
USING CSV
LOCATION 's3://kbpoc-ext-tmp/data/ext147_csv' ;

-- COMMAND ----------

INSERT INTO  pocdemo.uc_demo_db.ext147_csv VALUES (1, 'aa'), (2, 'bb');

-- COMMAND ----------

UPDATE pocdemo.uc_demo_db.ext147_csv SET num = 3 WHERE num = 2;

-- COMMAND ----------

SELECT * FROM pocdemo.uc_demo_db.ext147_csv

-- COMMAND ----------

INSERT INTO  pocdemo.uc_demo_db.ext147_csv VALUES (3, 'aa'), (4, 'bb');

-- COMMAND ----------

SELECT * FROM pocdemo.uc_demo_db.ext147_csv

-- COMMAND ----------

INSERT OVERWRITE TABLE  pocdemo.uc_demo_db.ext147_csv VALUES (5, 'aa'), (6, 'bb');

-- COMMAND ----------

SELECT * FROM pocdemo.uc_demo_db.ext147_csv

-- COMMAND ----------

