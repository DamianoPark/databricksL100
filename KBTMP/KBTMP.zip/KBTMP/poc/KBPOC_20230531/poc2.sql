-- Databricks notebook source
-- DBTITLE 1,2.2. 신청(추가), 승인 등의 API 지원 여부 -- 계정 생성 API
-- MAGIC %sh
-- MAGIC export DATABRICKS_TOKEN="dapi566f4c5793f8b2be6e2cc6332012a26b"
-- MAGIC
-- MAGIC curl -X POST --header "Authorization: Bearer $DATABRICKS_TOKEN" \
-- MAGIC   --header 'Content-type: application/scim+json' \
-- MAGIC   https://dbpoc-kbpoc-ext.cloud.databricks.com/api/2.0/account/scim/v2/Users \
-- MAGIC   -d '{
-- MAGIC         "schemas": [
-- MAGIC             "urn:ietf:params:scim:schemas:core:2.0:User"
-- MAGIC         ],
-- MAGIC         "userName": "yk_created_by_api@example.com",
-- MAGIC         "displayName": "yk API created"
-- MAGIC     }'

-- COMMAND ----------

-- DBTITLE 1,Check if user "created_by_api@example.com" is created
-- MAGIC %sh
-- MAGIC export DATABRICKS_TOKEN="dapi566f4c5793f8b2be6e2cc6332012a26b"
-- MAGIC
-- MAGIC curl -X GET --header "Authorization: Bearer $DATABRICKS_TOKEN" \
-- MAGIC   --header 'Content-type: application/scim+json' \
-- MAGIC   https://dbpoc-kbpoc-ext.cloud.databricks.com/api/2.0/account/scim/v2/Users 

-- COMMAND ----------

-- DBTITLE 1,Account user 를 workspace 에 등록 
-- MAGIC %sh
-- MAGIC export SCIM_TOKEN="dsapi985922632047676adb79de4886cc4361"
-- MAGIC
-- MAGIC curl -X PUT -k --header "Authorization: Bearer $SCIM_TOKEN" \
-- MAGIC   --header 'Content-type: application/scim+json' \
-- MAGIC   https://accounts.cloud.databricks.com/api/2.0/accounts/9f664544-1fdd-43f6-a32a-443017fad382/workspaces/2187597122825188/permissionassignments/principals/6255665230767882 \
-- MAGIC   -d '{
-- MAGIC         "permissions": [
-- MAGIC             "USER"
-- MAGIC         ]
-- MAGIC     }' 

-- COMMAND ----------

-- DBTITLE 1,Input password from prompt is working . 
-- MAGIC %sh 
-- MAGIC curl -X PUT -u yk.ko@databricks.com \
-- MAGIC   --header 'Content-type: application/scim+json' \
-- MAGIC   https://accounts.cloud.databricks.com/api/2.0/accounts/9f664544-1fdd-43f6-a32a-443017fad382/workspaces/2187597122825188/permissionassignments/principals/328906224275505 \
-- MAGIC   -d '{
-- MAGIC         "permissions": [
-- MAGIC             "USER"
-- MAGIC         ]
-- MAGIC     }'
-- MAGIC     
-- MAGIC Enter host password for user 'yk.ko@databricks.com':
-- MAGIC {"principal":{"user_name":"dklee@example.com","principal_id":328906224275505,"display_name":"API created by dklee"},"permissions":["USER"]}%

-- COMMAND ----------

-- DBTITLE 1,[추가] account level 의 API를 이용한 유저 생성 
-- MAGIC %sh
-- MAGIC # SCIM Token 생성: Account console > Settings > User provisioning 
-- MAGIC export SCIM_TOKEN="dsapi218c5b69404432da726a2c0c73b9cf8e"
-- MAGIC
-- MAGIC curl -X POST --header "Authorization: Bearer $SCIM_TOKEN" \
-- MAGIC   --header 'Content-type: application/scim+json' \
-- MAGIC   https://accounts.cloud.databricks.com/api/2.0/accounts/9f664544-1fdd-43f6-a32a-443017fad382/scim/v2/Users \
-- MAGIC   -d '{
-- MAGIC         "schemas": [
-- MAGIC             "urn:ietf:params:scim:schemas:core:2.0:User"
-- MAGIC         ],
-- MAGIC         "userName": "yk_account_api@example.com",
-- MAGIC         "displayName": "yk account API created"
-- MAGIC     }'

-- COMMAND ----------

-- DBTITLE 1,[추가] 유저를 account 에 등록 - username/pasword with base64 encoded 
-- MAGIC %sh 
-- MAGIC # username:password  > base64 encode > base64-username-pw
-- MAGIC # see https://docs.databricks.com/administration-guide/workspace/create-workspace-api.html
-- MAGIC
-- MAGIC base64_user_pw=`echo -n 'username:password' | base64`
-- MAGIC
-- MAGIC curl -X PUT -k --header "Authorization: Basic ${base64_user_pw}" \
-- MAGIC   -H "Content-Type: application/json" \
-- MAGIC   https://accounts.cloud.databricks.com/api/2.0/accounts/9f664544-1fdd-43f6-a32a-443017fad382/workspaces/2187597122825188/permissionassignments/principals/4702802836146303 \
-- MAGIC   -d '{
-- MAGIC         "permissions": [
-- MAGIC             "USER"
-- MAGIC         ]
-- MAGIC     }' 

-- COMMAND ----------

-- DBTITLE 1,Create token of a Service principal 
-- MAGIC %sh 
-- MAGIC export DATABRICKS_TOKEN="dapi566f4c5793f8b2be6e2cc6332012a26b"
-- MAGIC
-- MAGIC curl -X POST -k --header "Authorization: Bearer $DATABRICKS_TOKEN" \
-- MAGIC   -H "Content-Type: application/json" \
-- MAGIC   https://dbpoc-kbpoc-ext.cloud.databricks.com/api/2.0/token-management/on-behalf-of/tokens \
-- MAGIC   -d '{
-- MAGIC   "application_id": "22c15328-de5c-4758-a9ca-be157d45479a",
-- MAGIC   "lifetime_seconds": 36000000,
-- MAGIC   "comment": "on behalf of service principal"
-- MAGIC }'
-- MAGIC
-- MAGIC # {"token_value":"dapi26865b18bde4616b6fb1aca15e1101df","token_info":{"token_id":"07f97743947b72922f61459b1e986e156c80d86672e7e2aafedb53afa43b3107","creation_time":1683902168613,"expiry_time":1719902168613,"comment":"on behalf of service principal","created_by_id":4830597312325065,"created_by_username":"yk.ko@databricks.com","owner_id":702051944817740}}