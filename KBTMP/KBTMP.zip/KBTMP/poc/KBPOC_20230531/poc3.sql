-- Databricks notebook source
-- MAGIC %md
-- MAGIC ## 3.2. 컬럼별 권한 신청 및 승인

-- COMMAND ----------

-- DBTITLE 1,3.2. 컬럼별 권한 신청 및 승인 -- Dynamic View 사용 예
SELECT * FROM samples.tpch.customer 

-- COMMAND ----------

SHOW GROUPS WITH USER `yk.ko@databricks.com`

-- COMMAND ----------

-- DBTITLE 1,Dynamic View - Requires UC enabled cluster
CREATE OR REPLACE TEMP VIEW customer_redacted AS
SELECT
  c_custkey,
  CASE WHEN
    is_account_group_member('devgroup') THEN c_phone
    ELSE 'REDACTED'
  END AS c_phone
FROM samples.tpch.customer

-- COMMAND ----------

SELECT * FROM customer_redacted LIMIT 10

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW customer_redacted2 AS
SELECT
  c_custkey,
  CASE WHEN
    is_account_group_member('ANALYST_FRANCE') THEN c_phone
    ELSE 'REDACTED'
  END AS c_phone
FROM samples.tpch.customer

-- COMMAND ----------

SELECT * FROM customer_redacted2 LIMIT 10

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 3.3. 테이블 및 컬럼 권한 > API 기능 제공 여부
-- MAGIC * 문서: https://docs.databricks.com/api-explorer/workspace/grants/update

-- COMMAND ----------

CREATE TABLE pocdemo.uc_demo_db.myuctable (num INT, name STRING) 

-- COMMAND ----------

SHOW GRANTS `seungdon.choi@databricks.com` ON pocdemo.uc_demo_db.myuctable

-- COMMAND ----------

-- MAGIC %sh
-- MAGIC export DATABRICKS_TOKEN="dapi566f4c5793f8b2be6e2cc6332012a26b"
-- MAGIC
-- MAGIC curl -X PATCH --header "Authorization: Bearer $DATABRICKS_TOKEN" \
-- MAGIC   --header 'Content-type: application/json' \
-- MAGIC   https://dbpoc-kbpoc-ext.cloud.databricks.com/api/2.1/unity-catalog/permissions/table/pocdemo.uc_demo_db.myuctable \
-- MAGIC   -d '{
-- MAGIC         "changes": [
-- MAGIC             {
-- MAGIC             "principal": "seungdon.choi@databricks.com",
-- MAGIC             "add": [
-- MAGIC                 "SELECT"
-- MAGIC             ],
-- MAGIC             "remove": [
-- MAGIC                 "MODIFY"
-- MAGIC             ]
-- MAGIC             }
-- MAGIC         ]
-- MAGIC     }' 

-- COMMAND ----------

SHOW GRANTS `seungdon.choi@databricks.com` ON pocdemo.uc_demo_db.myuctable

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 3.4. External location

-- COMMAND ----------

DROP EXTERNAL LOCATION IF EXISTS `kbpoc-uc-extloc-tmp`

-- COMMAND ----------

-- DBTITLE 1,Without External location, create external table fails.
CREATE TABLE pocdemo.uc_demo_db.ext34 (num INT, name STRING)
LOCATION 's3://kbpoc-ext-tmp/data/ext34'

-- COMMAND ----------

-- DBTITLE 1,After create External location
CREATE EXTERNAL LOCATION IF NOT EXISTS `kbpoc-uc-extloc-tmp`
URL 's3://kbpoc-ext-tmp/data'
WITH ( STORAGE CREDENTIAL `kbpoc-storage-credential-uc` )
COMMENT 'tmp ext loc for KBPOC' ;

-- COMMAND ----------

-- DBTITLE 1,Create External table is successful.
CREATE TABLE pocdemo.uc_demo_db.ext34 (num INT, name STRING)
LOCATION 's3://kbpoc-ext-tmp/data/ext34'

-- COMMAND ----------

DESC FORMATTED pocdemo.uc_demo_db.ext34 

-- COMMAND ----------

DROP TABLE pocdemo.uc_demo_db.ext34 

-- COMMAND ----------

