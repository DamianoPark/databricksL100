# Databricks notebook source
# MAGIC %md
# MAGIC ## ETL Audit log 
# MAGIC * doc: https://www.databricks.com/blog/2020/06/02/monitor-your-databricks-workspace-with-audit-logs.html
# MAGIC * notebook: https://www.databricks.com/notebooks/Audit-Logs-ETL.html

# COMMAND ----------

from pyspark.sql.functions import udf, col, from_unixtime, from_utc_timestamp, from_json
from pyspark.sql.types import StringType, StructField, StructType
import json, time, requests

# COMMAND ----------

sourceBucket = "s3://kbpoc-ext-audit/auditlog"
sinkBucket = "s3://kbpoc-ext-audit/auditdelta"

# COMMAND ----------

def stripNulls(raw):
  return json.dumps({i: raw.asDict()[i] for i in raw.asDict() if raw.asDict()[i] != None})

strip_udf = udf(stripNulls, StringType())

# COMMAND ----------

streamSchema = spark.read.json(sourceBucket).schema

# COMMAND ----------

streamDF = (
  spark
  .readStream
  .format("json")
  .schema(streamSchema)
  .load(sourceBucket)
)

# COMMAND ----------

(streamDF
  .withColumn("flattened", strip_udf("requestParams"))
  .withColumn("email", col("userIdentity.email"))
  .withColumn("date_time", from_utc_timestamp(from_unixtime(col("timestamp")/1000), "UTC"))
  .drop("requestParams")
  .drop("userIdentity")
  .writeStream
  .format("delta")
  .partitionBy("date")
  .outputMode("append")
  .option("checkpointLocation", "{}/checkpoints/bronze".format(sinkBucket))
  .option("path", "{}/streaming/bronze".format(sinkBucket))
  .option("mergeSchema", True)
  .trigger(once=True)
  .start()
)

# COMMAND ----------

while spark.streams.active != []:
  print("Waiting for streaming query to finish.")
  time.sleep(5)

# COMMAND ----------

spark.sql("""
CREATE TABLE IF NOT EXISTS pocdemo.auditlog.refined
USING DELTA
LOCATION '{}/streaming/bronze'
""".format(sinkBucket))

# COMMAND ----------

# MAGIC %sql SELECT count(*) FROM pocdemo.auditlog.refined

# COMMAND ----------

# MAGIC %sql
# MAGIC optimize pocdemo.auditlog.refined

# COMMAND ----------

