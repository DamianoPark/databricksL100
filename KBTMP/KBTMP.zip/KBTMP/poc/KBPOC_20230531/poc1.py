# Databricks notebook source
# MAGIC %md
# MAGIC ## 1.1. 데이터 수집 > 데이터 적재 > S3 → "대상 솔루션" 파일 기반 데이터 적재 및 확인
# MAGIC * 지원 여부: 지원
# MAGIC * 상세: Auto loader, Delta Live Tables, COPY INTO 등의 방식으로 파일 데이터 적재 가능 
# MAGIC * 문서:  https://docs.databricks.com/external-data/index.html\
# MAGIC * 예제: 노트북  https://docs.databricks.com/_extras/notebooks/source/read-csv-files.html

# COMMAND ----------

# DBTITLE 1,방법 1. SQL을 이용한 데이터셋 탐색
# MAGIC %sql
# MAGIC CREATE TEMPORARY VIEW diamonds
# MAGIC USING CSV
# MAGIC OPTIONS (path "/Volumes/lakehouse/netflixdata/netflixdata/netflixdata.csv", header "true")
# MAGIC ;
# MAGIC SELECT * FROM diamonds;

# COMMAND ----------

# DBTITLE 1,방법 2. dataframe 으로 데이터셋 탐색 
datapath = "/Volumes/lakehouse/netflixdata/netflixdata/netflixdata.csv"
diamondsDF = spark.read.format("csv")\
              .option("header","true")\
              .option("inferschema","true")\
              .load(datapath)

display(diamondsDF)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1.2. 데이터 수집 > 데이터 적재 > 사용자 정의 구분자 (ex. \036, ||)
# MAGIC * 지원 여부: 지원
# MAGIC * 상세: Autoloader의 CSV 옵션 중 sep 또는 delimiter 로 컬럼 구분자, lineSep 으로 라인 구분자 지정 
# MAGIC * 문서: https://docs.databricks.com/ingestion/auto-loader/options.html#csv-options
# MAGIC

# COMMAND ----------

# DBTITLE 1,구분자가 cntl-A (\001) 인 csv 파일 
# MAGIC %fs head dbfs:/FileStore/tables/KBPOC/data_1_2_1.csv

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TEMPORARY TABLE t12_new
# MAGIC USING CSV
# MAGIC OPTIONS (path "dbfs:/FileStore/tables/KBPOC/data_1_2_1.csv", delimiter "\001")
# MAGIC ;
# MAGIC SELECT * FROM t12_new;

# COMMAND ----------

# DBTITLE 1,구분자가 | 인 csv
# MAGIC %fs head dbfs:/FileStore/tables/KBPOC/data_1_2_2.csv

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TEMPORARY TABLE t12_pipe
# MAGIC USING CSV
# MAGIC OPTIONS (path "dbfs:/FileStore/tables/KBPOC/data_1_2_2.csv", delimiter "|")
# MAGIC ;
# MAGIC SELECT * FROM t12_pipe;

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1.3. euc-kr 파일을 utf-8 저장
# MAGIC * 지원 여부: 지원
# MAGIC * 상세: encoding or charset 을 지정
# MAGIC * 문서: https://docs.databricks.com/ingestion/auto-loader/options.html#csv-options

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TEMPORARY TABLE t13
# MAGIC USING CSV
# MAGIC OPTIONS (path "dbfs:/FileStore/tables/KBPOC/data_1_3_cp949.csv", header "true")
# MAGIC ;
# MAGIC SELECT * FROM t13;

# COMMAND ----------

# DBTITLE 1,방법 1. Table 생성시 encoding 옵션 지정
# MAGIC %sql
# MAGIC CREATE TEMPORARY TABLE t13_new
# MAGIC USING CSV
# MAGIC OPTIONS (path "dbfs:/FileStore/tables/KBPOC/data_1_3_cp949.csv", header "true", encoding "cp949")
# MAGIC ;
# MAGIC SELECT * FROM t13_new;

# COMMAND ----------

# DBTITLE 1,방법 2. dataframe 에서 encoding 옵션으로 읽기
encode_df = spark.read.format("csv")\
              .option("header","true")\
              .option("inferschema","true")\
              .option("encoding", "cp949") \
              .load("dbfs:/FileStore/tables/KBPOC/data_1_3_cp949.csv")
display(encode_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1.5. 고정길이 데이터 적재
# MAGIC * 지원 여부: 지원
# MAGIC * 상세: 
# MAGIC * 문서: https://community.databricks.com/s/question/0D53f00001HKHCqCAP/how-to-read-a-fixed-length-file-in-spark-using-dataframe-api-and-scala 

# COMMAND ----------

# MAGIC %sql
# MAGIC -- char(N), varchar(N) with default setting. Note length(c5) can be 3 instead of 5
# MAGIC SET spark.sql.readSideCharPadding = false;
# MAGIC
# MAGIC DROP TABLE IF EXISTS  pocdemo.uc_demo_db.t15 ;
# MAGIC
# MAGIC CREATE TABLE pocdemo.uc_demo_db.t15 (id INT, c5 char(5), vc10 varchar(10) );
# MAGIC
# MAGIC INSERT INTO pocdemo.uc_demo_db.t15 VALUES (1, '12345', '123'), (2, '123', '1234');
# MAGIC
# MAGIC SELECT id, c5, length(c5), vc10, length(vc10) FROM pocdemo.uc_demo_db.t15;

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- spark.sql.readSideCharPadding (https://databricks.atlassian.net/browse/ES-443817)
# MAGIC SET spark.sql.readSideCharPadding = true;
# MAGIC
# MAGIC DROP TABLE IF EXISTS  pocdemo.uc_demo_db.t15 ;
# MAGIC
# MAGIC CREATE TABLE pocdemo.uc_demo_db.t15 (id INT, c5 char(5), vc10 varchar(10) );
# MAGIC
# MAGIC INSERT INTO pocdemo.uc_demo_db.t15 VALUES (1, '12345', '123'), (2, '123', '1234');
# MAGIC
# MAGIC -- '123' is padded to '123  '
# MAGIC SELECT id, c5, '#' || c5 || '#' as c5_padded, length(c5), vc10, length(vc10) FROM pocdemo.uc_demo_db.t15;

# COMMAND ----------

# DBTITLE 1,항목별 포지션과 길이를 지정하여 고정 길이 컬럼 파일 읽기  
# MAGIC %fs head dbfs:/FileStore/tables/KBPOC/data_1_5_fixedlength.txt

# COMMAND ----------

# borrowed from https://stackoverflow.com/questions/41944689/pyspark-parse-fixed-width-text-file
from pyspark.sql.functions import col

# define (column, position, length)
schema = [
          ("id",1,5),
          ("ssn",6,10),
          ("name",16,4)
]

df = spark.read.text("dbfs:/FileStore/tables/KBPOC/data_1_5_fixedlength.txt")
df.show() 

for colinfo in schema:
  df = df.withColumn(colinfo[0], df.value.substr(colinfo[1],colinfo[2]))

df2 = df.drop("value")
df2.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1.6. 압축파일 데이터 load
# MAGIC * 지원 여부: 지원
# MAGIC * 상세: 압축 포맷을 그대로 지원

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TEMPORARY TABLE t16
# MAGIC USING CSV
# MAGIC OPTIONS (path "dbfs:/FileStore/tables/KBPOC/data_1_6.gz", header "true")
# MAGIC ;
# MAGIC SELECT * FROM t16;

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1.7. JDBC/ODBC connection DB --> 데이터 적재
# MAGIC * 지원 여부: 확인 필요 
# MAGIC * 상세: JDBC/ODBC 데이터 소스에 연결하여 데이터 적재 가능.
# MAGIC * 문서: https://docs.databricks.com/external-data/jdbc.html
# MAGIC * Test용 DB 셋업 필요 (eg. RDS) 

# COMMAND ----------

# MAGIC %sql 
# MAGIC CREATE TABLE IF NOT EXISTS hive_metastore.default.jdbc_ext_table3
# MAGIC   USING JDBC
# MAGIC OPTIONS (
# MAGIC   url "jdbc:mysql://database-2.cxqstnlvt6ek.ap-northeast-2.rds.amazonaws.com:3306/sys",
# MAGIC   dbtable "sys_config",
# MAGIC   user 'kbbank',
# MAGIC   password 'KB!Bank1234'
# MAGIC );

# COMMAND ----------

# MAGIC %sql 
# MAGIC SELECT * FROM hive_metastore.default.jdbc_ext_table

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1.8. JDBC/ODBC connection DB --> euc-kr 인코딩 데이터 utf-8 저장

# COMMAND ----------

# WIP. Need to check 
remote_table = (spark.read
  .format("jdbc")
  .option("driver", "org.mariadb.jdbc.Driver")
  .option("url", jdbc_url)
  .option("dbtable", "test")
  .option("encoding", "CP949")
  .load()
  .write
  .mode("overwrite")
  .option("encoding", "UTF-8")
  .saveAsTable("pocdemo.uc_demo_db.t17_new")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 추가 : 2023/05/11

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE pocdemo.uc_demo_db.yk_csv_data3; 
# MAGIC
# MAGIC CREATE TABLE pocdemo.uc_demo_db.yk_csv_data3 (str1 string, str2 string, int1 int) 
# MAGIC USING CSV 
# MAGIC OPTIONS (
# MAGIC   path "s3://kbpoc-ext-data/upload/euckr_036_test", 
# MAGIC   -- header "true", 
# MAGIC   encoding "cp949", 
# MAGIC   inferSchema "true",
# MAGIC   delimiter "\036"
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql select * from csv.`s3://kbpoc-ext-data/upload/euckr_036_test`

# COMMAND ----------

# MAGIC %sql select * from pocdemo.uc_demo_db.yk_csv_data3

# COMMAND ----------

# MAGIC %sql desc formatted pocdemo.uc_demo_db.yk_csv_data3

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1.7. 추가 : JDBC 에서 read, JDBC 로 write
# MAGIC * 문서: https://docs.databricks.com/external-data/jdbc.html#language-sql 

# COMMAND ----------

# MAGIC %sh 
# MAGIC nc -vz dbpoc-kbpoc-ext.cloud.databricks.com 443

# COMMAND ----------

# DBTITLE 1,CREATE TABLE USING JDBC
# MAGIC %sql
# MAGIC
# MAGIC CREATE TEMP VIEW jdbc_table 
# MAGIC USING JDBC
# MAGIC OPTIONS (
# MAGIC   url "jdbc:databricks://dbpoc-kbpoc-ext.cloud.databricks.com:443/default;transportMode=http;ssl=1;AuthMech=3;httpPath=/sql/1.0/warehouses/2a28a21a4d8e39bc;",
# MAGIC   dbtable "pocdemo.uc_demo_db.ext34",
# MAGIC   user 'token',
# MAGIC   password 'dapi566f4c5793f8b2be6e2cc6332012a26b'
# MAGIC );

# COMMAND ----------

# MAGIC %sql 
# MAGIC
# MAGIC SELECT * FROM jdbc_table;

# COMMAND ----------

# MAGIC %sql 
# MAGIC INSERT INTO jdbc_table values (9, null, 'added into Table using JDBC');

# COMMAND ----------

# MAGIC %sql SELECT * FROM jdbc_table;

# COMMAND ----------

