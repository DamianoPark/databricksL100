-- Databricks notebook source
-- MAGIC %md
-- MAGIC ## 거버넌스 - 컬럼 메타  
-- MAGIC * 한글명 테이블 및 컬럼 생성, 변경
-- MAGIC * 전체 테이블 조회
-- MAGIC * 전체 컬럼 조회
-- MAGIC * 특정 테이블 내 컬럼명 조회
-- MAGIC * 특정 컬럼 포함 테이블 목록 조회

-- COMMAND ----------

-- DBTITLE 1,7.1. 한글 테이블명, 컬럼명 with Unity Catalog
CREATE TABLE pocdemo.uc_demo_db.`테스트1` (
 `name` STRING ,
 `번호` INT 
)

-- COMMAND ----------

INSERT INTO pocdemo.uc_demo_db.`테스트1` (`name`, `번호`) VALUES ('aaa', 1), ('홍길도',1), ('여의도', 2);

-- COMMAND ----------

SELECT * FROM pocdemo.uc_demo_db.`테스트1` WHERE `번호` = 1 ;

-- COMMAND ----------

DESC FORMATTED pocdemo.uc_demo_db.`테스트1`;

-- COMMAND ----------

-- DBTITLE 1,7.2 전체 테이블 조회 
SELECT * FROM pocdemo.information_schema.tables 

-- COMMAND ----------

-- DBTITLE 1,7.3 전체 컬럼 조회
SELECT * FROM pocdemo.information_schema.columns 
WHERE table_catalog='pocdemo'
AND table_schema = 'uc_demo_db'
ORDER BY table_name, ordinal_position

-- COMMAND ----------

-- DBTITLE 1,7.4. 특정 테이블 내 컬럼명 조회
SELECT * FROM pocdemo.information_schema.columns 
WHERE table_catalog='pocdemo'
AND table_schema = 'uc_demo_db'
AND table_name = '테스트1'; 

-- COMMAND ----------

-- DBTITLE 1,7.5 특정 컬럼 포함 테이블 목록 조회
SELECT * FROM pocdemo.information_schema.columns 
WHERE table_catalog='pocdemo'
AND table_schema = 'uc_demo_db'
AND column_name = 'num' 

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 7.6. 테이블 및 컬럼 변경 이력 조회
-- MAGIC * DESC HISTORY tablename
-- MAGIC * or
-- MAGIC * Workspace UI : Data explorer > table > History   

-- COMMAND ----------

CREATE TABLE pocdemo.uc_demo_db.t76 (
 `name` STRING ,
 `번호` INT 
)

-- COMMAND ----------

ALTER TABLE pocdemo.uc_demo_db.t76 ADD COLUMN ( col3 STRING )

-- COMMAND ----------

  ALTER TABLE  pocdemo.uc_demo_db.t76 SET TBLPROPERTIES (
    'delta.minReaderVersion' = '2',
    'delta.minWriterVersion' = '5',
    'delta.columnMapping.mode' = 'name'
  )

-- COMMAND ----------

ALTER TABLE pocdemo.uc_demo_db.t76 RENAME COLUMN col3 TO col3_renamed

-- COMMAND ----------

DESC pocdemo.uc_demo_db.t76

-- COMMAND ----------

INSERT INTO pocdemo.uc_demo_db.t76 VALUES ('AAA', 1, 'FOO')

-- COMMAND ----------

DESC HISTORY pocdemo.uc_demo_db.t76