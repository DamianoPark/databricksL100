-- Databricks notebook source
-- MAGIC %md
-- MAGIC ## 5.2. 제공 암호화 알고리즘
-- MAGIC * 문서: https://docs.databricks.com/sql/language-manual/functions/aes_encrypt.html

-- COMMAND ----------

SELECT base64(aes_encrypt('KB은행', 'abcdefghijklmnop'));

-- COMMAND ----------

SELECT cast(aes_decrypt(unbase64('UBBKCXDVGZxwv7yk1cFWxH4yuz7+D8aoTJ9xl2NulfUIy4WL'),
                          'abcdefghijklmnop') AS STRING);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 5.3. 암호화 키 관리 
-- MAGIC * 문서: https://docs.databricks.com/security/secrets/index.html
-- MAGIC
-- MAGIC ```
-- MAGIC # create secret scope
-- MAGIC databricks secrets --profile KBPOC create-scope --scope pii
-- MAGIC
-- MAGIC # put secret "piikey" to the secret scope "pii" (ex. 01234567890_KPBOC )
-- MAGIC databricks secrets --profile KBPOC put --scope pii --key piikey
-- MAGIC
-- MAGIC # list secret scope 
-- MAGIC databricks secrets --profile KBPOC list-scopes 
-- MAGIC
-- MAGIC Scope    Backend     KeyVault URL
-- MAGIC -------  ----------  --------------
-- MAGIC pii      DATABRICKS  N/A
-- MAGIC
-- MAGIC # list secret in the scope "pii"
-- MAGIC databricks secrets --profile KBPOC list --scope pii
-- MAGIC
-- MAGIC Key name      Last updated
-- MAGIC ----------  --------------
-- MAGIC piikey       1683653630719
-- MAGIC
-- MAGIC ```

-- COMMAND ----------

-- MAGIC %python
-- MAGIC dbutils.secrets.get(scope="pii", key="piikey")

-- COMMAND ----------

-- MAGIC %scala
-- MAGIC val piikey = dbutils.secrets.get(scope = "pii", key = "piikey")
-- MAGIC print(piikey)

-- COMMAND ----------

-- DBTITLE 1,Use secret in SQL
-- doc:  https://docs.databricks.com/sql/language-manual/functions/secret.html
SELECT * FROM list_secrets();

-- COMMAND ----------

-- function secret(scope, key)
SELECT secret('pii', 'piikey');

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 5.4. 쿼리 기반의 특정 컬럼 암호화, 복호화
-- MAGIC * 현재 3.2 의 Dynamic View 기능으로 구현 가능 
-- MAGIC * 문서: https://docs.databricks.com/data-governance/unity-catalog/create-views.html#dynamic-view
-- MAGIC * [Private Preview] Column level masking : spark.databricks.sql.rowColumnAccess.enabled

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW customer_redacted AS
SELECT
  c_custkey,
  CASE WHEN
    is_account_group_member('devgroup') THEN c_phone
    ELSE 'REDACTED'  -- or base64(aes_encrypt(c_phone, 'abcdefghijklmnop'));
  END AS c_phone
FROM samples.tpch.customer
;

SELECT * FROM customer_redacted LIMIT 10;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## [추가] 컬럼 레벨 마스킹 기능 - Private Preview
-- MAGIC * 문서: 
-- MAGIC * 예제: private preview enabled 내부 환경으로, 로그인 필요 
-- MAGIC *  https://e2-dogfood.staging.cloud.databricks.com/?o=6051921418418893#notebook/2272171370889790/command/2272171370889805 

-- COMMAND ----------

-- Create a SQL user defined function.
CREATE FUNCTION ssn_mask(ssn STRING)
RETURN IF(IS_MEMBER('admin'), ssn, "****");

-- Apply the new function to a table as a column  mask.
-- Future users' queries from the 'ssn' column then return
-- altered values.
CREATE TABLE users (region STRING, table_ssn STRING) USING delta;
ALTER TABLE users ALTER COLUMN table_ssn SET MASK ssn_mask;

-- Disable the column mask. Future users' queries from the 'ssn'
-- column then return original values.
ALTER TABLE users ALTER COLUMN table_ssn DROP MASK;

-- Create another table with the new function applied as a column
-- mask in one step, as part of the create table statement. 
-- Future users' queries from the 'ssn' column then return
-- altered values.
CREATE TABLE region_to_ssn (
  region STRING,
  ssn STRING MASK ssn_mask)
USING delta;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## [추가 5.3] AWS Secrets Manager
-- MAGIC * need to add SecretsManagerReadWrite policy to instance profile

-- COMMAND ----------

-- MAGIC %python
-- MAGIC import requests
-- MAGIC import boto3
-- MAGIC from botocore.exceptions import ClientError
-- MAGIC from botocore.config import Config
-- MAGIC
-- MAGIC region="ap-northeast-2"
-- MAGIC
-- MAGIC def create_secret(name, secret_value):
-- MAGIC     """
-- MAGIC     Creates a new secret. The secret value can be a string or bytes.
-- MAGIC     """
-- MAGIC     secrets_client = boto3.client("secretsmanager", region_name=region)
-- MAGIC     kwargs = {"Name": name}
-- MAGIC     if isinstance(secret_value, str):
-- MAGIC         kwargs["SecretString"] = secret_value
-- MAGIC     elif isinstance(secret_value, bytes):
-- MAGIC         kwargs["SecretBinary"] = secret_value
-- MAGIC     response = secrets_client.create_secret(**kwargs)
-- MAGIC     return response
-- MAGIC
-- MAGIC
-- MAGIC def get_secret_value(name, version=None):
-- MAGIC     """Gets the value of a secret.
-- MAGIC
-- MAGIC     Version (if defined) is used to retrieve a particular version of
-- MAGIC     the secret.
-- MAGIC
-- MAGIC     """
-- MAGIC     secrets_client = boto3.client("secretsmanager", region_name=region)
-- MAGIC     kwargs = {'SecretId': name}
-- MAGIC     if version is not None:
-- MAGIC         kwargs['VersionStage'] = version
-- MAGIC     response = secrets_client.get_secret_value(**kwargs)
-- MAGIC     #return response
-- MAGIC     return response['SecretString']
-- MAGIC
-- MAGIC # create_secret("my-test-secret-str", "kb-test-secret-str")
-- MAGIC
-- MAGIC print(get_secret_value("my-test-secret-str"))

-- COMMAND ----------

-- MAGIC %md 
-- MAGIC ## [추가 5.3] 데이터브릭스 Secrets API 사용시 권한 관리
-- MAGIC * API, CLI 로 권한 관리
-- MAGIC * 문서: https://docs.databricks.com/security/secrets/index.html
-- MAGIC
-- MAGIC ```
-- MAGIC databricks secrets -help
-- MAGIC
-- MAGIC Commands:
-- MAGIC   create-scope  Creates a secret scope.
-- MAGIC   delete        Deletes a secret.
-- MAGIC   delete-acl    Deletes an access control rule for a principal.
-- MAGIC   delete-scope  Deletes a secret scope.
-- MAGIC   get-acl       Gets the details for an access control rule.
-- MAGIC   list          Lists all the secrets in a scope.
-- MAGIC   list-acls     Lists all access control rules for a given secret scope.
-- MAGIC   list-scopes   Lists all secret scopes.
-- MAGIC   put           Puts a secret in a scope. "write" is an alias for "put".
-- MAGIC   put-acl       Creates or overwrites an access control rule for a principal
-- MAGIC                 applied to a given secret scope. "write-acl" is an alias for
-- MAGIC                 "put-acl".
-- MAGIC   write         Puts a secret in a scope. "write" is an alias for "put".
-- MAGIC   write-acl     Creates or overwrites an access control rule for a principal
-- MAGIC                 applied to a given secret scope. "write-acl" is an alias for
-- MAGIC                 "put-acl".
-- MAGIC ```

-- COMMAND ----------

-- DBTITLE 1,기본적으로 secret scope를 생성한 유저만 권한을 가지게 됨 
-- MAGIC %sh 
-- MAGIC DATABRICKS_TOKEN="dapi566f4c5793f8b2be6e2cc6332012a26b"
-- MAGIC
-- MAGIC curl --netrc --request GET --header "Authorization: Bearer $DATABRICKS_TOKEN" \
-- MAGIC https://dbpoc-kbpoc-ext.cloud.databricks.com/api/2.0/secrets/acls/list \
-- MAGIC -d '{
-- MAGIC   "scope": "pii"
-- MAGIC }'

-- COMMAND ----------

-- DBTITLE 1,"devgroup" 그룹에게 secret scope "pii" 에 대한 MANAGE 권한 부여 
-- MAGIC %sh 
-- MAGIC DATABRICKS_TOKEN="dapi566f4c5793f8b2be6e2cc6332012a26b"
-- MAGIC
-- MAGIC curl --netrc --request POST --header "Authorization: Bearer $DATABRICKS_TOKEN" \
-- MAGIC https://dbpoc-kbpoc-ext.cloud.databricks.com/api/2.0/secrets/acls/put \
-- MAGIC -d '{
-- MAGIC   "scope": "pii",
-- MAGIC   "principal": "frontist@yahoo.co.kr",
-- MAGIC   "permission": "READ"
-- MAGIC }'

-- COMMAND ----------

-- MAGIC %sh 
-- MAGIC DATABRICKS_TOKEN="dapi566f4c5793f8b2be6e2cc6332012a26b"
-- MAGIC
-- MAGIC curl --netrc --request GET --header "Authorization: Bearer $DATABRICKS_TOKEN" \
-- MAGIC https://dbpoc-kbpoc-ext.cloud.databricks.com/api/2.0/secrets/acls/list \
-- MAGIC -d '{
-- MAGIC   "scope": "pii"
-- MAGIC }'

-- COMMAND ----------

-- DBTITLE 1,"devgroup" 에 속한 유저로 체크
-- MAGIC %python
-- MAGIC dbutils.secrets.get(scope="pii", key="piikey")

-- COMMAND ----------

-- DBTITLE 1,"devgroup"의 권한 삭제
-- MAGIC %sh 
-- MAGIC DATABRICKS_TOKEN="dapi566f4c5793f8b2be6e2cc6332012a26b"
-- MAGIC
-- MAGIC curl --netrc --request POST --header "Authorization: Bearer $DATABRICKS_TOKEN" \
-- MAGIC https://dbpoc-kbpoc-ext.cloud.databricks.com/api/2.0/secrets/acls/delete \
-- MAGIC -d '{
-- MAGIC   "scope": "pii",
-- MAGIC   "principal": "devgroup"  
-- MAGIC }'

-- COMMAND ----------

-- MAGIC %sh 
-- MAGIC DATABRICKS_TOKEN="dapi566f4c5793f8b2be6e2cc6332012a26b"
-- MAGIC
-- MAGIC curl --netrc --request GET --header "Authorization: Bearer $DATABRICKS_TOKEN" \
-- MAGIC https://dbpoc-kbpoc-ext.cloud.databricks.com/api/2.0/secrets/acls/list \
-- MAGIC -d '{
-- MAGIC   "scope": "pii"
-- MAGIC }'

-- COMMAND ----------

-- DBTITLE 1,권한 삭제 후 "devgroup"에 속한 유저로 체크
-- MAGIC %python
-- MAGIC dbutils.secrets.get(scope="pii", key="piikey")