-- Databricks notebook source
-- MAGIC %md
-- MAGIC ## 13.1. SQL 및 Python UDF 지원 여부

-- COMMAND ----------

-- DBTITLE 1,SQL UDF
CREATE OR REPLACE FUNCTION pocdemo.uc_demo_db.area(x DOUBLE, y DOUBLE) RETURNS DOUBLE RETURN x * y;

-- COMMAND ----------

SELECT pocdemo.uc_demo_db.area(3, 7)

-- COMMAND ----------

USE pocdemo.uc_demo_db;
SELECT area(3, 7);

-- COMMAND ----------

-- DBTITLE 1,Python UDF
-- MAGIC %python
-- MAGIC
-- MAGIC from pyspark.sql.types import LongType
-- MAGIC
-- MAGIC def squared_typed(s):
-- MAGIC   return s * s
-- MAGIC
-- MAGIC spark.udf.register("squaredWithPython", squared_typed, LongType())

-- COMMAND ----------

CREATE TEMPORARY VIEW test (id) AS 
SELECT 2 
UNION ALL 
SELECT 3 

-- COMMAND ----------

select id, squaredWithPython(id) as id_squared from test

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### DBSQL 에서 Python UDF 지원 기능은 현재 Private preview 진행중 
-- MAGIC * 가이드: https://docs.google.com/document/d/1aLo1BbWlmAiy4loixHFcVMifu4_Y6NC10423zI8cXHc/edit#heading=h.7q3gw6syn1wo
-- MAGIC * Preview 프로그램에 workspace 를 등록하여 activate 필요
-- MAGIC * SQL Warehouse 또는 compute cluster 생성시, Tags 에 PythonUDF.enable true 를 추가.   

-- COMMAND ----------

-- DBTITLE 1,Python UDF
-- 
CREATE FUNCTION pocdemo.uc_demo_db.area_python(x DOUBLE, y DOUBLE)
RETURNS DOUBLE
LANGUAGE PYTHON
AS $$
import random
rand = random.random()
return x * y * rand 
$$;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 13.2. UDF 권한 부여 
-- MAGIC * Legacy hive metastore 의 table access control: https://docs.databricks.com/data-governance/table-acls/table-acl.html 
-- MAGIC * Hive metastore 의 Privilege type : https://docs.databricks.com/sql/language-manual/sql-ref-privileges-hms.html
-- MAGIC * Unity catalog  의 Privilege type : https://docs.databricks.com/data-governance/unity-catalog/manage-privileges/privileges.html
-- MAGIC * FUNCTION 에 대해, legacy HMS 에서는 SELECT, Unity Catlog 에서는 EXECUTE 권한을 제공.

-- COMMAND ----------

-- DBTITLE 1,UDF in Unity catalog
DESC FUNCTION pocdemo.uc_demo_db.area;

-- COMMAND ----------

GRANT EXECUTE ON FUNCTION pocdemo.uc_demo_db.area to `seungdon.choi@databricks.com`

-- COMMAND ----------

GRANT SELECT ON FUNCTION pocdemo.uc_demo_db.area to `seungdon.choi@databricks.com`

-- COMMAND ----------

-- DBTITLE 1,Hive metastore
USE hive_metastore.default; 

-- COMMAND ----------

CREATE FUNCTION hms_area(x DOUBLE, y DOUBLE) RETURNS DOUBLE RETURN x * y;

-- COMMAND ----------

DESC FUNCTION hive_metastore.default.hms_area;

-- COMMAND ----------

SHOW USER FUNCTIONS IN hive_metastore.default;

-- COMMAND ----------

SELECT hive_metastore.default.hms_area(3,8);

-- COMMAND ----------

GRANT SELECT ON FUNCTION hive_metastore.default.hms_area to `seungdon.choi@databricks.com`

-- COMMAND ----------

GRANT EXECUTE ON FUNCTION hive_metastore.default.hms_area to `seungdon.choi@databricks.com`

-- COMMAND ----------

