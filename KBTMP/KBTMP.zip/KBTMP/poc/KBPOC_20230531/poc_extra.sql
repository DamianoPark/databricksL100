-- Databricks notebook source
-- MAGIC %python
-- MAGIC mytable = 'pocdemo.uc_demo_db.ext34'
-- MAGIC display(spark.sql(f"""SELECT * FROM {mytable} LIMIT 10"""))

-- COMMAND ----------

-- MAGIC %python
-- MAGIC dbutils.widgets.removeAll()
-- MAGIC dbutils.widgets.text("widgettable", "pocdemo.uc_demo_db.ext34")

-- COMMAND ----------

SELECT '${widgettable}' as pararm, * FROM ${widgettable} LIMIT 10

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Table size in Bytes

-- COMMAND ----------

-- MAGIC %python 
-- MAGIC
-- MAGIC def table_size(schemas):
-- MAGIC     count = 0
-- MAGIC     size = spark.sql(f”DESCRIBE DETAIL {schemas.serviceid}_{target_schema}.{schemas.eventcode}“).select(‘sizeInBytes’).collect()[0].sizeInBytes
-- MAGIC     return size
-- MAGIC
-- MAGIC schemas = spark.table(pocdemo.uc_demo_db)
-- MAGIC

-- COMMAND ----------

-- DBTITLE 1,Delta table
-- MAGIC %python
-- MAGIC #spark.sql("describe detail pocdemo.uc_demo_db.ext34").select("sizeInBytes").collect().select("sizeInBytes").collect()
-- MAGIC display(spark.sql("describe detail pocdemo.uc_demo_db.ext34").select("sizeInBytes").collect())

-- COMMAND ----------

-- MAGIC %scala
-- MAGIC spark.read.table("pocdemo.uc_demo_db.yk_csv_data3").queryExecution.analyzed.stats

-- COMMAND ----------

-- MAGIC %scala
-- MAGIC import com.databricks.sql.transaction.tahoe._
-- MAGIC val deltaLog = DeltaLog.forTable(spark, "dbfs:/user/hive/warehouse/poc_data")
-- MAGIC val snapshot = deltaLog.unsafeVolatileSnapshot
-- MAGIC println(s"Total file size (bytes): ${snapshot.sizeInBytes}")
-- MAGIC // val snapshot = deltaLog.snapshot  
-- MAGIC // println(s"Total file size (bytes): ${deltaLog.snapshot.sizeInBytes}")

-- COMMAND ----------




-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC def table_size(tablename):
-- MAGIC     count = 0
-- MAGIC     size = spark.sql(f"DESCRIBE DETAIL {tablename}").select('sizeInBytes').collect()[0].sizeInBytes
-- MAGIC     return size
-- MAGIC
-- MAGIC def sum_table_size(schema_name):
-- MAGIC     size_total = 0
-- MAGIC     tables =  spark.sql(f"SHOW TABLES IN {schema_name}").select('tableName')
-- MAGIC     for tbl in tables.collect():
-- MAGIC         table_name = schema_name + '.`' + tbl['tableName'] + '`'
-- MAGIC         size = table_size(table_name)
-- MAGIC         print(f"table: {table_name} , size: {size}")
-- MAGIC         if isinstance(size, int):
-- MAGIC             size_total = size_total + size 
-- MAGIC     return size_total 
-- MAGIC
-- MAGIC sum_size = sum_table_size("`pocdemo`.`uc_demo_db`")
-- MAGIC print(sum_size)  

-- COMMAND ----------

select * from  poc_test.anal_dept.test_table_1 limit 100;

-- COMMAND ----------

SELECT * FROM pocdemo.uc_demo_db.test_double;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Iceberg Tables

-- COMMAND ----------

SET spark.sql.catalog.dev = shaded.databricks.org.apache.iceberg.spark.SparkCatalog;
--   SET spark.sql.catalog.dev.type = hadoop; 
SET spark.sql.catalog.dev.warehouse = s3://kbpoc-ext-tmp/iceberg_data/;
SET `spark.sql.catalog.dev.catalog-impl` = shaded.databricks.org.apache.iceberg.aws.glue.GlueCatalog;
SET `spark.sql.catalog.dev.io-impl` = shaded.databricks.org.apache.iceberg.aws.s3.S3FileIO;
SET `spark.sql.catalog.dev.cache-enabled` = false;

-- COMMAND ----------

CREATE OR REPLACE TABLE pocdemo.uc_demo_db.delta_sclone_iceberg SHALLOW CLONE dev.iceberg_data.iceberg_table
-- iceberg.`s3://kbpoc-ext-tmp/iceberg_data/iceberg_table`;

-- COMMAND ----------

-- MAGIC %fs ls s3://kbpoc-ext-tmp/iceberg_data/iceberg_table/

-- COMMAND ----------

SELECT * FROM iceberg.`s3://kbpoc-ext-tmp/iceberg_data/iceberg_table`;

-- COMMAND ----------

