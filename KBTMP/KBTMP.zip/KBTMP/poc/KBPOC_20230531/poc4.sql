-- Databricks notebook source
-- DBTITLE 1,create audit log table 
CREATE TABLE IF NOT EXISTS pocdemo.auditlog.audit_logs
USING JSON
OPTIONS (path="s3a://kbpoc-ext-audit/auditlog")
;

-- COMMAND ----------

SELECT * FROM pocdemo.auditlog.audit_logs

-- COMMAND ----------

DESC FORMATTED pocdemo.auditlog.audit_logs

-- COMMAND ----------

