-- Databricks notebook source
-- MAGIC %md
-- MAGIC ## 6.2. 데이터 백업 및 복구

-- COMMAND ----------

USE test_db;

-- COMMAND ----------

CREATE TABLE test_db.t62 (num INT, name STRING);

-- COMMAND ----------

INSERT INTO  test_db.t62 VALUES (1, 'A');
INSERT INTO  test_db.t62 VALUES (2, 'B');
INSERT INTO  test_db.t62 VALUES (3, 'C');

-- COMMAND ----------

DESC HISTORY test_db.t62;

-- COMMAND ----------

SELECT * FROM test_db.t62 VERSION AS OF 2;

-- COMMAND ----------

RESTORE TABLE test_db.t62 TO VERSION AS OF 2;

-- COMMAND ----------

SELECT * FROM test_db.t62;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 6.3. DROP 테이블 복구

-- COMMAND ----------

CREATE TABLE pocdemo.uc_demo_db.drop_test_ext 
USING DELTA 
LOCATION "s3://kbpoc-ext-tmp/data/drop_test_ext"
AS SELECT * FROM samples.tpch.customer LIMIT 100000;

-- COMMAND ----------

SHOW CREATE TABLE  pocdemo.uc_demo_db.drop_test_ext;

-- COMMAND ----------

DESC FORMATTED pocdemo.uc_demo_db.drop_test_ext;

-- COMMAND ----------

DROP TABLE  pocdemo.uc_demo_db.drop_test_ext;

-- COMMAND ----------

desc formatted  pocdemo.uc_demo_db.drop_test_ext;

-- COMMAND ----------

-- DBTITLE 1,Drop한 external 테이블을 재생성  (동일 LOCATION 과 스키마 지정) 
CREATE TABLE pocdemo.uc_demo_db.drop_test_ext (
  c_custkey BIGINT,   c_name STRING,   c_address STRING,   c_nationkey BIGINT,   
  c_phone STRING,   c_acctbal DECIMAL(18,2),   c_mktsegment STRING,   c_comment STRING) 
USING delta 
LOCATION 's3://kbpoc-ext-tmp/data/drop_test_ext' 

-- COMMAND ----------

desc formatted  pocdemo.uc_demo_db.drop_test_ext;

-- COMMAND ----------

select * from  pocdemo.uc_demo_db.drop_test_ext;

-- COMMAND ----------

