# Databricks notebook source
# MAGIC %md
# MAGIC ## 11.4. 테스트

# COMMAND ----------

def reverse(s):
    return s[::-1]

# COMMAND ----------

def square(a):
    return a*a

# COMMAND ----------

import unittest

class TestHelpers(unittest.TestCase):
    def test_reverse(self):
        self.assertEqual(reverse('abc'), 'cba')
    
    def test_square(self):
        self.assertEqual(square(7), 40)

r = unittest.main(argv=[''], verbosity=2, exit=False)
assert r.result.wasSuccessful(), 'Test failed; see logs above'

# COMMAND ----------

# MAGIC %md
# MAGIC ### Use Databricks widgets to select notebook mode 

# COMMAND ----------

dbutils.widgets.dropdown('Mode', 'Test', ['Test', 'Normal'])

import unittest

if dbutils.widgets.get('Mode') == 'Test':
    assert reverse('abc') == 'cbd'
    print('Test Passwd')
else:
    print(reverse('desrever'))


# COMMAND ----------

# MAGIC %md
# MAGIC ### Unit test using Databricks Repos

# COMMAND ----------

# MAGIC %sh
# MAGIC
# MAGIC cd /Workspace/Repos/dev/unittest
# MAGIC pwd 
# MAGIC ls 
# MAGIC
# MAGIC python -m unittest -v shared_test.py

# COMMAND ----------

# MAGIC %sh head /Workspace/Repos/dev/unittest/shared_test.py

# COMMAND ----------

