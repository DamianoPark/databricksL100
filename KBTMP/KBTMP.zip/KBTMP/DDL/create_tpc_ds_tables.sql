-- Databricks notebook source
SET basepath = '/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet';

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.call_center AS 
SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/call_center", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.catalog_page AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/catalog_page", format => 'parquet');

-- COMMAND ----------


CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.catalog_returns AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/catalog_returns", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.catalog_sales AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/catalog_sales", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.customer AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/customer", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.customer_address AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/customer_address", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.customer_demographics AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/customer_demographics", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.date_dim AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/date_dim", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.household_demographics AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/household_demographics", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.income_band AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/income_band", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.inventory AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/inventory", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.item AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/item", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.promotion AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/promotion", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.reason AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/reason", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.ship_mode AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/ship_mode", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.store AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/store", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.store_returns AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/store_returns", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.store_sales AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/store_sales", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.time_dim AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/time_dim", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.warehouse AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/warehouse", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.web_page AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/web_page", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.web_returns AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/web_returns", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.web_sales AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/web_sales", format => 'parquet');

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS tpc_ds.tpc_ds.web_site AS SELECT * FROM read_files("/Volumes/tpc_ds/tpc_ds/tpc_ds/source_files_010TB_parquet/web_site", format => 'parquet');