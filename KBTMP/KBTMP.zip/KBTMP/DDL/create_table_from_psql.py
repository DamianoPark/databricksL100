# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE pbagent.genai.TSMFAPB01 AS
# MAGIC SELECT * FROM genai_prd_psql_catalog.public.tsmfapb01 LIMIT 0;

# COMMAND ----------

# MAGIC %sql
# MAGIC show create table pbagent.genai.TSMFAPB01

# COMMAND ----------

for nn in range(1,60):
    if nn == 51:  # TSMFAPB51 does not exists in psql 
        continue
    tbl = f"TSMFAPB{nn:02}"
    sql = f"""
        CREATE OR REPLACE TABLE pbagent.genai.{tbl} AS
        SELECT * FROM genai_prd_psql_catalog.public.{tbl} LIMIT 0;
    """
    #print(sql) 
    spark.sql(sql)
