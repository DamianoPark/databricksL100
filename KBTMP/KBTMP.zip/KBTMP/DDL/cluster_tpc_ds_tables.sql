-- Databricks notebook source



-- COMMAND ----------

ALTER TABLE tpc_ds.tpc_ds.store_sales CLUSTER BY (ss_sold_date_sk, ss_customer_sk, ss_store_sk, ss_item_sk);


-- COMMAND ----------

ALTER TABLE tpc_ds.tpc_ds.date_dim CLUSTER BY (d_date_sk, d_date);


-- COMMAND ----------

ALTER TABLE tpc_ds.tpc_ds.store CLUSTER BY (s_store_sk, s_state);


-- COMMAND ----------

ALTER TABLE tpc_ds.tpc_ds.store_returns CLUSTER BY (sr_returned_date_sk, sr_customer_sk, sr_item_sk, sr_ticket_number);


-- COMMAND ----------

ALTER TABLE tpc_ds.tpc_ds.catalog_sales CLUSTER BY (cs_sold_date_sk, cs_bill_customer_sk, cs_item_sk);


-- COMMAND ----------

ALTER TABLE tpc_ds.tpc_ds.item CLUSTER BY (i_item_sk, i_item_id, i_item_desc);

-- COMMAND ----------

