-- Databricks notebook source
ALTER TABLE pbagent.genai.tsmfapb01 ALTER COLUMN `상품코드` SET NOT NULL;

-- COMMAND ----------

ALTER TABLE pbagent.genai.tsmfapb01 ADD CONSTRAINT `tsmfapb01` PRIMARY KEY (`상품코드`);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB02
-- MAGIC

-- COMMAND ----------

ALTER TABLE pbagent.genai.tsmfapb02 ALTER COLUMN `대표펀드코드` SET NOT NULL;

-- COMMAND ----------

ALTER TABLE pbagent.genai.tsmfapb02 ADD CONSTRAINT `tsmfapb02` PRIMARY KEY (`대표펀드코드`);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB03
-- MAGIC

-- COMMAND ----------

ALTER TABLE pbagent.genai.tsmfapb03 ALTER COLUMN `상품코드` SET NOT NULL;

-- COMMAND ----------

ALTER TABLE pbagent.genai.tsmfapb03 ADD CONSTRAINT `tsmfapb03` PRIMARY KEY (`상품코드`);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB04
-- MAGIC 상품코드
-- MAGIC WM자산군구분
-- MAGIC

-- COMMAND ----------

ALTER TABLE pbagent.genai.tsmfapb04 ALTER COLUMN `상품코드` SET NOT NULL; 
ALTER TABLE pbagent.genai.tsmfapb04 ALTER COLUMN `WM자산군구분` SET NOT NULL;

-- COMMAND ----------

ALTER TABLE pbagent.genai.tsmfapb04 ADD CONSTRAINT `tsmfapb04` PRIMARY KEY (`상품코드`, `wm자산군구분`);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB05
-- MAGIC 상품코드, 투자지역분류코드
-- MAGIC
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb05 alter column `상품코드` set not null;
alter table pbagent.genai.tsmfapb05 alter column `투자지역분류코드` set not null;


-- COMMAND ----------

alter table pbagent.genai.tsmfapb05 add constraint `tsmfapb05` primary key (`상품코드`, `투자지역분류코드`);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB06
-- MAGIC 상품코드
-- MAGIC 주식업종분류코드
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb06 alter column `상품코드` set not null;
alter table pbagent.genai.tsmfapb06 alter column `주식업종분류코드` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb06 add constraint `tsmfapb06` primary key (`상품코드`, `주식업종분류코드`);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB07
-- MAGIC 상품코드
-- MAGIC 채권등급분류코드
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb07 alter column `상품코드` set not null;
alter table pbagent.genai.tsmfapb07 alter column `채권등급분류코드` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb07 add constraint `tsmfapb07` primary key (`상품코드`, `채권등급분류코드`);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB08
-- MAGIC 상품코드
-- MAGIC 채권만기분류코드
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb08 alter column `상품코드` set not null;
alter table pbagent.genai.tsmfapb08 alter column `채권만기분류코드` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb08 add constraint `tsmfapb08` primary key (`상품코드`, `채권만기분류코드`);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB09
-- MAGIC 상품코드
-- MAGIC 편입종목명
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb09 alter column `상품코드` set not null;
alter table pbagent.genai.tsmfapb09 alter column `편입종목명` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb09 add constraint `tsmfapb09` primary key (`상품코드`, `편입종목명`);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB10
-- MAGIC 상품코드
-- MAGIC 주식투자스타일구분
-- MAGIC 주식투자규모구분
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb10 alter column `상품코드` set not null;
alter table pbagent.genai.tsmfapb10 alter column `주식투자스타일구분` set not null;
alter table pbagent.genai.tsmfapb10 alter column `주식투자규모구분` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb10 add constraint `tsmfapb10` primary key (`상품코드`, `주식투자스타일구분`, `주식투자규모구분`);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB11
-- MAGIC 상품코드
-- MAGIC 채권듀레이션구분
-- MAGIC 채권신용도구분
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb11 alter column `상품코드` set not null;
alter table pbagent.genai.tsmfapb11 alter column `채권듀레이션구분` set not null;
alter table pbagent.genai.tsmfapb11 alter column `채권신용도구분` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb11 add constraint `tsmfapb11` primary key (`상품코드`, `채권듀레이션구분`, `채권신용도구분`);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB12
-- MAGIC 기준년월일
-- MAGIC 상품코드
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb12 alter column `상품코드` set not null;
alter table pbagent.genai.tsmfapb12 alter column `기준년월일` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb12 add constraint `tsmfapb12` primary key (`상품코드`, `기준년월일`);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB13
-- MAGIC 기준년월일
-- MAGIC 대표펀드코드
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb13 alter column `대표펀드코드` set not null;
alter table pbagent.genai.tsmfapb13 alter column `기준년월일` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb13 add constraint `tsmfapb13` primary key (`대표펀드코드`, `기준년월일`);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB14
-- MAGIC MP번호
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb14 alter column `MP번호` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb14 add constraint `tsmfapb14` primary key (`mp번호`);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB15
-- MAGIC 기준년월일
-- MAGIC MP번호
-- MAGIC 상품코드
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb15 alter column `상품코드` set not null;
alter table pbagent.genai.tsmfapb15 alter column `기준년월일` set not null;
alter table pbagent.genai.tsmfapb15 alter column `mp번호` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb15 add constraint `tsmfapb15` primary key (`상품코드`, `기준년월일`, `mp번호`);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB16
-- MAGIC MP번호
-- MAGIC 기준년월일
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb16 alter column `기준년월일` set not null;
alter table pbagent.genai.tsmfapb16 alter column `mp번호` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb16 add constraint `tsmfapb16` primary key (`기준년월일`, `mp번호`);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB17
-- MAGIC MP번호
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb17 alter column `mp번호` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb17 add constraint `tsmfapb17` primary key (`mp번호`);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB18
-- MAGIC 기준년월일
-- MAGIC MP번호
-- MAGIC 상품코드
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb18 alter column `mp번호` set not null;
alter table pbagent.genai.tsmfapb18 alter column `기준년월일` set not null;
alter table pbagent.genai.tsmfapb18 alter column `상품코드` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb18 add constraint `tsmfapb18` primary key (`mp번호`, `기준년월일`, `상품코드`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB19
-- MAGIC MP번호
-- MAGIC 기준년월일
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb19 alter column `mp번호` set not null;
alter table pbagent.genai.tsmfapb19 alter column `기준년월일` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb19 add constraint `tsmfapb19` primary key (`mp번호`, `기준년월일`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB20
-- MAGIC 투자성향구분
-- MAGIC WMTI투자전략구분
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb20 alter column `투자성향구분` set not null;
alter table pbagent.genai.tsmfapb20 alter column `wmti투자전략구분` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb20 add constraint `tsmfapb20` primary key (`투자성향구분`, `wmti투자전략구분`);

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB21
-- MAGIC 투자성향구분
-- MAGIC WMTI투자전략구분
-- MAGIC WM자산군구분
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb21 alter column `wm자산군구분` set not null;
alter table pbagent.genai.tsmfapb21 alter column `wmti투자전략구분` set not null;
alter table pbagent.genai.tsmfapb21 alter column `투자성향구분` set not null;


-- COMMAND ----------

alter table pbagent.genai.tsmfapb21 add constraint `tsmfapb21` primary key (`wm자산군구분`, `wmti투자전략구분`, `투자성향구분`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB22
-- MAGIC 기준년월일
-- MAGIC 투자성향구분
-- MAGIC WMTI투자전략구분
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb22 alter column `wmti투자전략구분` set not null;
alter table pbagent.genai.tsmfapb22 alter column `투자성향구분` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb22 add constraint `tsmfapb22` primary key (`wmti투자전략구분`, `투자성향구분`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB23
-- MAGIC 고객투자성향구분
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb23 alter column `고객투자성향구분` set not null;


-- COMMAND ----------

alter table pbagent.genai.tsmfapb23 add constraint `tsmfapb23` primary key (`고객투자성향구분`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB24
-- MAGIC 고객투자성향구분
-- MAGIC WM자산군구분
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb24 alter column `wm자산군구분` set not null;
alter table pbagent.genai.tsmfapb24 alter column `고객투자성향구분` set not null;


-- COMMAND ----------

alter table pbagent.genai.tsmfapb24 add constraint `tsmfapb24` primary key (`wm자산군구분`, `고객투자성향구분`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB25
-- MAGIC 기준년월일
-- MAGIC 고객투자성향구분
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb25 alter column `고객투자성향구분` set not null;
alter table pbagent.genai.tsmfapb25 alter column `기준년월일` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb25 add constraint `tsmfapb25` primary key (`고객투자성향구분`, `기준년월일`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB26
-- MAGIC 기준년월일
-- MAGIC 시장지표코드
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb26 alter column `시장지표코드` set not null;
alter table pbagent.genai.tsmfapb26 alter column `기준년월일` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb26 add constraint `tsmfapb26` primary key (`시장지표코드`, `기준년월일`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB27
-- MAGIC 시장지수코드
-- MAGIC 기준년월일
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb27 alter column `시장지수코드` set not null;
alter table pbagent.genai.tsmfapb27 alter column `기준년월일` set not null;


-- COMMAND ----------

alter table pbagent.genai.tsmfapb27 add constraint `tsmfapb27` primary key (`시장지수코드`, `기준년월일`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB28
-- MAGIC 기준년월일
-- MAGIC 티커코드
-- MAGIC KB자산운용유형명
-- MAGIC WM자산군구분
-- MAGIC 지표명
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb28 alter column `기준년월일` set not null;
alter table pbagent.genai.tsmfapb28 alter column `티커코드` set not null;
alter table pbagent.genai.tsmfapb28 alter column `kb자산운용유형명` set not null;
alter table pbagent.genai.tsmfapb28 alter column `wm자산군구분` set not null;
alter table pbagent.genai.tsmfapb28 alter column `지표명` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb28 add constraint `tsmfapb28` primary key (`기준년월일`, `티커코드`, `kb자산운용유형명`, `wm자산군구분`, `지표명`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB29
-- MAGIC 연령5세구간구분
-- MAGIC 성별구분
-- MAGIC 실질고객구분
-- MAGIC 대표펀드코드
-- MAGIC
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb29 alter column `연령5세구간구분` set not null;
alter table pbagent.genai.tsmfapb29 alter column `성별구분` set not null;
alter table pbagent.genai.tsmfapb29 alter column `실질고객구분` set not null;
alter table pbagent.genai.tsmfapb29 alter column `대표펀드코드` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb29 add constraint `tsmfapb29` primary key (`연령5세구간구분`, `성별구분`, `실질고객구분`, `대표펀드코드`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB30
-- MAGIC 계좌번호
-- MAGIC 고객식별자
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb30 alter column `계좌번호` set not null;
alter table pbagent.genai.tsmfapb30 alter column `고객식별자` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb30 add constraint `tsmfapb30` primary key (`계좌번호`, `고객식별자`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB31
-- MAGIC 고객식별자
-- MAGIC 계좌번호
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb31 alter column `계좌번호` set not null;
alter table pbagent.genai.tsmfapb31 alter column `고객식별자` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb31 add constraint `tsmfapb31` primary key (`계좌번호`, `고객식별자`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB32
-- MAGIC WMTI판정방법구분
-- MAGIC 판정년월일
-- MAGIC 고객식별자
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb32 alter column `wmti판정방법구분` set not null;
alter table pbagent.genai.tsmfapb32 alter column `판정년월일` set not null;
alter table pbagent.genai.tsmfapb32 alter column `고객식별자` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb32 add constraint `tsmfapb32` primary key (`wmti판정방법구분`, `판정년월일`, `고객식별자`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB33
-- MAGIC 고객식별자
-- MAGIC 성향분석일련번호
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb33 alter column `고객식별자` set not null;
alter table pbagent.genai.tsmfapb33 alter column `성향분석일련번호` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb33 add constraint `tsmfapb33` primary key (`고객식별자`, `성향분석일련번호`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB34
-- MAGIC 고객식별자
-- MAGIC 성향분석일련번호
-- MAGIC 설문일련번호
-- MAGIC 선택문항번호
-- MAGIC 선택항목번호
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb34 alter column `고객식별자` set not null;
alter table pbagent.genai.tsmfapb34 alter column `성향분석일련번호` set not null;
alter table pbagent.genai.tsmfapb34 alter column `설문일련번호` set not null;
alter table pbagent.genai.tsmfapb34 alter column `선택문항번호` set not null;
alter table pbagent.genai.tsmfapb34 alter column `선택항목번호` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb34 add constraint `tsmfapb34` primary key (`고객식별자`, `성향분석일련번호`, `설문일련번호`, `선택문항번호`, `선택항목번호`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB35
-- MAGIC 고객식별자
-- MAGIC 고객관리부점코드
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb35 alter column `고객식별자` set not null;
alter table pbagent.genai.tsmfapb35 alter column `고객관리부점코드` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb35 add constraint `tsmfapb35` primary key (`고객식별자`, `고객관리부점코드`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB36
-- MAGIC 고객식별자
-- MAGIC
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb36 alter column `고객식별자` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb36 add constraint `tsmfapb36` primary key (`고객식별자`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB37
-- MAGIC WMTI구분
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb37 alter column `wmti구분` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb37 add constraint `tsmfapb37` primary key (`wmti구분`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB38
-- MAGIC 기준년월일
-- MAGIC 뉴스분석시간구분
-- MAGIC 뉴스클라우드시장구분
-- MAGIC 뉴스순위
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb38 alter column `기준년월일` set not null;
alter table pbagent.genai.tsmfapb38 alter column `뉴스분석시간구분` set not null;
alter table pbagent.genai.tsmfapb38 alter column `뉴스클라우드시장구분` set not null;
alter table pbagent.genai.tsmfapb38 alter column `뉴스순위` set not null;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB39
-- MAGIC 기준년월일
-- MAGIC 뉴스분석시간구분
-- MAGIC 뉴스클라우드시장구분
-- MAGIC 뉴스순위
-- MAGIC 뉴스일련번호
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb39 alter column `기준년월일` set not null;
alter table pbagent.genai.tsmfapb39 alter column `뉴스분석시간구분` set not null;
alter table pbagent.genai.tsmfapb39 alter column `뉴스클라우드시장구분` set not null;
alter table pbagent.genai.tsmfapb39 alter column `뉴스순위` set not null;
alter table pbagent.genai.tsmfapb39 alter column `뉴스일련번호` set not null;



-- COMMAND ----------

alter table pbagent.genai.tsmfapb39 add constraint `tsmfapb39` primary key (`기준년월일`, `뉴스분석시간구분`, `뉴스클라우드시장구분`, `뉴스순위`, `뉴스일련번호`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB40
-- MAGIC 기준년월일
-- MAGIC 컨센서스전망구분
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb40 alter column `기준년월일` set not null;
alter table pbagent.genai.tsmfapb40 alter column `컨센서스전망구분` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb40 add constraint `tsmfapb40` primary key (`기준년월일`, `컨센서스전망구분`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB41
-- MAGIC 적용년월
-- MAGIC WM투자자산군구분
-- MAGIC WM투자자산군세부구분
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb41 alter column `적용년월` set not null;
alter table pbagent.genai.tsmfapb41 alter column `wm투자자산군구분` set not null;
alter table pbagent.genai.tsmfapb41 alter column `wm투자자산군세부구분` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb41 add constraint `tsmfapb41` primary key (`적용년월`, `wm투자자산군구분`, `wm투자자산군세부구분`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB42
-- MAGIC 이벤트년월일
-- MAGIC 이벤트일련번호
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb42 alter column `이벤트년월일` set not null;
alter table pbagent.genai.tsmfapb42 alter column `이벤트일련번호` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb42 add constraint `tsmfapb42` primary key (`이벤트년월일`, `이벤트일련번호`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB43
-- MAGIC 기준년월일
-- MAGIC WM주요지수구분
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb43 alter column `기준년월일` set not null;
alter table pbagent.genai.tsmfapb43 alter column `wm주요지수구분` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb43 add constraint `tsmfapb43` primary key (`기준년월일`, `wm주요지수구분`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB44
-- MAGIC 그룹회사코드
-- MAGIC 기준년월일
-- MAGIC 키워드검색기간구분
-- MAGIC 파티션번호
-- MAGIC 키워드내용
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb44 alter column `그룹회사코드` set not null;
alter table pbagent.genai.tsmfapb44 alter column `기준년월일` set not null;
alter table pbagent.genai.tsmfapb44 alter column `키워드검색기간구분` set not null;
alter table pbagent.genai.tsmfapb44 alter column `파티션번호` set not null;
alter table pbagent.genai.tsmfapb44 alter column `키워드내용` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb44 add constraint `tsmfapb44` primary key (`그룹회사코드`, `기준년월일`, `키워드검색기간구분`, `파티션번호`, `키워드내용`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB45
-- MAGIC 기준년월일
-- MAGIC WM주요지표구분
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb45 alter column `기준년월일` set not null;
alter table pbagent.genai.tsmfapb45 alter column `wm주요지표구분` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb45 add constraint `tsmfapb45` primary key (`기준년월일`, `wm주요지표구분`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB46
-- MAGIC 기준년월일
-- MAGIC 유사국면시장구분
-- MAGIC 유사국면순위
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb46 alter column `기준년월일` set not null;
alter table pbagent.genai.tsmfapb46 alter column `유사국면시장구분` set not null;
alter table pbagent.genai.tsmfapb46 alter column `유사국면순위` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb46 add constraint `tsmfapb46` primary key (`기준년월일`, `유사국면시장구분`, `유사국면순위`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB47
-- MAGIC 뉴스년월일
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb47 alter column `뉴스년월일` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb47 add constraint `tsmfapb47` primary key (`뉴스년월일`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB48
-- MAGIC 기준년월일
-- MAGIC 뉴스년월일
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb48 alter column `기준년월일` set not null;
alter table pbagent.genai.tsmfapb48 alter column `뉴스년월일` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb48 add constraint `tsmfapb48` primary key (`기준년월일`, `뉴스년월일`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB49
-- MAGIC 기준년월일
-- MAGIC 지수기준년월일
-- MAGIC 유사국면순위
-- MAGIC WM주요지표구분
-- MAGIC 유사국면지수기간구분
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb49 alter column `기준년월일` set not null;
alter table pbagent.genai.tsmfapb49 alter column `지수기준년월일` set not null;
alter table pbagent.genai.tsmfapb49 alter column `유사국면순위` set not null;
alter table pbagent.genai.tsmfapb49 alter column `wm주요지표구분` set not null;
alter table pbagent.genai.tsmfapb49 alter column `유사국면지수기간구분` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb49 add constraint `tsmfapb49` primary key (`기준년월일`, `지수기준년월일`, `유사국면순위`, `wm주요지표구분`, `유사국면지수기간구분`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB50
-- MAGIC 기준년월일
-- MAGIC 지수기준년월일
-- MAGIC 유사국면순위
-- MAGIC WM주요지표구분
-- MAGIC 유사국면지수기간구분
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb50 alter column `기준년월일` set not null;
alter table pbagent.genai.tsmfapb50 alter column `지수기준년월일` set not null;
alter table pbagent.genai.tsmfapb50 alter column `wm주요지표구분` set not null;
alter table pbagent.genai.tsmfapb50 alter column `유사국면순위` set not null;
alter table pbagent.genai.tsmfapb50 alter column `유사국면지수기간구분` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb50 add constraint `tsmfapb50` primary key (`기준년월일`, `지수기준년월일`, `wm주요지표구분`, `유사국면순위`, `유사국면지수기간구분`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB52
-- MAGIC WM주요지수구분
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb52 alter column `wm주요지수구분` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb52 add constraint `tsmfapb52` primary key (`wm주요지수구분`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB53
-- MAGIC 기준년월일
-- MAGIC 컨센서스전망구분
-- MAGIC 문장일련번호
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb53 alter column `기준년월일` set not null;
alter table pbagent.genai.tsmfapb53 alter column `컨센서스전망구분` set not null;
alter table pbagent.genai.tsmfapb53 alter column `문장일련번호` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb53 add constraint `tsmfapb53` primary key (`기준년월일`, `컨센서스전망구분`, `문장일련번호`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB54
-- MAGIC 기준년월일
-- MAGIC 편중포트폴리오배분구분
-- MAGIC 배분분류구분
-- MAGIC
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb54 alter column `기준년월일` set not null;
alter table pbagent.genai .tsmfapb54 alter column `편중포트폴리오배분구분` set not null;
alter table pbagent.genai .tsmfapb54 alter column `배분분류구분` set not null;

-- COMMAND ----------

alter table pbagent.genai .tsmfapb54 add constraint `tsmfapb54` primary key (`기준년월일`, `편중포트폴리오배분구분`, `배분분류구분`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB55
-- MAGIC 고객식별자
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb55 alter column `고객식별자` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb55 add constraint `tsmfapb55` primary key (`고객식별자`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB56
-- MAGIC 고객발굴코드
-- MAGIC 고객식별자
-- MAGIC 계좌번호
-- MAGIC 상품계약회차
-- MAGIC 통화코드
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb56 alter column `고객발굴코드` set not null;
alter table pbagent.genai.tsmfapb56 alter column `고객식별자` set not null;
alter table pbagent.genai.tsmfapb56 alter column `계좌번호` set not null;
alter table pbagent.genai.tsmfapb56 alter column `상품계약회차` set not null;
alter table pbagent.genai.tsmfapb56 alter column `통화코드` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb56 add constraint `tsmfapb56` primary key (`고객발굴코드`, `고객식별자`, `계좌번호`, `상품계약회차`, `통화코드`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB57
-- MAGIC 고객발굴코드
-- MAGIC 고객식별자
-- MAGIC 계좌번호
-- MAGIC 상품계약회차
-- MAGIC 거래년월일
-- MAGIC 거래일련번호
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb57 alter column `고객발굴코드` set not null;
alter table pbagent.genai.tsmfapb57 alter column `고객식별자` set not null;
alter table pbagent.genai.tsmfapb57 alter column `계좌번호` set not null;
alter table pbagent.genai.tsmfapb57 alter column `상품계약회차` set not null;
alter table pbagent.genai.tsmfapb57 alter column `거래년월일` set not null;
alter table pbagent.genai.tsmfapb57 alter column `거래일련번호` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb57 add constraint `tsmfapb57` primary key (`고객발굴코드`, `고객식별자`, `계좌번호`, `상품계약회차`, `거래년월일`, `거래일련번호`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB58
-- MAGIC 직원번호
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb58 alter column `직원번호` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb58 add constraint `tsmfapb58` primary key (`직원번호`)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC TCTEAPB59
-- MAGIC 부점코드
-- MAGIC
-- MAGIC

-- COMMAND ----------

alter table pbagent.genai.tsmfapb59 alter column `부점코드` set not null;

-- COMMAND ----------

alter table pbagent.genai.tsmfapb59 add constraint `tsmfapb59` primary key (`부점코드`)

-- COMMAND ----------

